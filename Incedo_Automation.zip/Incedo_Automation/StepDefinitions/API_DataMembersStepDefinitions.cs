using Incedo_Automation.src.utils;
using NUnit.Framework;
using RestSharp;
using Incedo_Automation.src.library.API_libs;

namespace Incedo_Automation.StepDefinitions
{
    [Binding]
    public class API_DataMembersStepDefinitions
    {
        public string Data = "";
        private RestResponse _response;


        [Given(@"Send code to encrypt ""([^""]*)""")]
        public void GivenSendCodeToEncrypt(string inputValue)
        {
            Data = EncryptionUtil.EncodeKey(inputValue);
        }

        [Given(@"Send code to decrypt ""([^""]*)""")]
        public void GivenSendCodeToDecrypt(string inputval)
        {
            Data = EncryptionUtil.DecodeKey(inputval);
        }


        [Then(@"Print encrypted data")]
        public void ThenPrintEncryptedData()
        {
            System.Console.WriteLine("Encrypted data is : " + Data);
        }

        [When(@"Decrypt data")]
        public void WhenDecryptData()
        {
            Data = EncryptionUtil.DecodeKey(Data);
        }

        [Then(@"Print decrypted data")]
        public void ThenPrintDecryptedData()
        {
            System.Console.WriteLine("Encrypted data is : " + Data);

        }

        [Given(@"Launch ""([^""]*)"" endpoint with valid credentials")]
        public void GivenLaunchEndpointWithValidCredentials(string endpoint)
        {
            _response = apiRequest.GetAPIRequestAsync(endpoint);
        }

        [Then(@"Verify status code as ""([^""]*)""")]
        public void ThenVerifyStatusCodeAs(string statuscode)
        {
            Assert.AreEqual(int.Parse(statuscode), (int)_response.StatusCode);
        }

        [Given(@"Launch ""([^""]*)"" endpoint with invalid credentials")]
        public void GivenLaunchEndpointWithInvalidCredentials(string endpoint)
        {
            _response = apiRequest.GetAPIRequestAsync(endpoint);
        }

        [When(@"Validate Get member states response")]
        public void WhenValidateGetMemberStatesResponse()
        {
            Assert.IsNotEmpty(_response.Content);
        }

        [When(@"Validate Get member states response schema")]
        public void WhenValidateGetMemberStatesResponseSchema()
        {
            Assert.IsNotEmpty(_response.Content);
        }

        [Given(@"I have a valid API endpoint")]
        public async Task GivenIHaveAValidAPIEndpointAsync()
        {
            var options = new RestClientOptions("https://reqres.in")
            {
                MaxTimeout = -1,
            };
            var client = new RestClient(options);
            var request = new RestRequest("/api/users?page=2", Method.Get);
            RestResponse response = await client.ExecuteAsync(request);
            Console.WriteLine(response.Content);


            _response = response;
        }

        [When(@"I send a GET request")]
        public void WhenISendAGETRequest()
        {

        }

        [Then(@"the response status code should be (.*)")]
        public void ThenTheResponseStatusCodeShouldBe(int expectedStatusCode)
        {
            Assert.AreEqual(expectedStatusCode, (int)_response.StatusCode);
        }

        [When(@"Validate Get member states response schemasdsdfasdf")]
        public void WhenValidateGetMemberStatesResponseSchemasdsdfasdf()
        {
            throw new PendingStepException();
        }

    }
}
