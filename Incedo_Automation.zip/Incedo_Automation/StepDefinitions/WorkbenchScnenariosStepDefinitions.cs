using Incedo_Automation.src.utility;
using NUnit.Framework;
using SharpCompress.Common;
using System;
using TechTalk.SpecFlow;

namespace Incedo_Automation.StepDefinitions
{
    [Binding]
    public class WorkbenchScnenariosStepDefinitions
    {
        private string sourceFilePath;
        private string destinationFolderPath = "";
        private string processedFileName;
        private bool fileProcessed;
        public string dbResult;

        [Given(@"a Member file exists at ""([^""]*)""")]
        public void GivenAMemberFileExistsAt(string sourcePath)
        {
            sourceFilePath = sourcePath;
        }

        [When(@"The file is copied to ""([^""]*)"" under UnProcessed folder")]
        public void WhenTheFileIsCopiedTo(string destinationPath)
        {
            destinationFolderPath = destinationPath.Replace("c:\\", "");
            // Implement file copying logic here
            File.Copy(sourceFilePath, Path.Combine(destinationPath, "UnProcessed", Path.GetFileName(sourceFilePath)), true);
        }

        [When(@"I wait for (.*) seconds")]
        public void WhenIWaitForSeconds(int seconds)
        {
            Thread.Sleep(seconds * 1000);
        }

        [Then(@"The file should be Processed")]
        public void ThenTheFileShouldBeProcessed()
        {
            // Implement logic to check if the file is processed
            //processedFileName = Path.GetFileName(sourceFilePath + "//Processed");
            bool fileExists = File.Exists(Path.Combine(destinationFolderPath, "Processed", Path.GetFileName(sourceFilePath)));
            fileProcessed = true; // Replace with your actual logic
            Assert.IsTrue(fileExists, "File Not found at location " + destinationFolderPath + "\\Processed");

        }

        [Then(@"The file should be Inprocess")]
        public void ThenTheFileShouldBeInprocess()
        {
            // Implement logic to check if the file is processed
            //processedFileName = Path.GetFileName(sourceFilePath + "//InProcess");
            bool fileExists = File.Exists(Path.Combine(destinationFolderPath, "InProcess", Path.GetFileName(sourceFilePath)));

            fileProcessed = true; // Replace with your actual logic
            Assert.IsTrue(fileExists, "File Not found at location " + destinationFolderPath + "\\InProcess");

        }


        [Then(@"I hit SQL query to get the latest file logs")]
        public void ThenIHitSQLQueryToGetTheLatestFileLogs()
        {
            // Implement SQL query logic to get file logs
            dbResult = dbConnect.getBatchStatus("select top 1 * from batch order by createdate desc", 5);
        }

        [Then(@"I verify if data is uploaded")]
        public void ThenIVerifyIfDataIsUploaded()
        {
            string[] value = dbResult.Split("|");

            Assert.IsTrue(value[2] == "7", "file is not COMPLETED");
            // Implement logic to check if data is uploaded
        }

        [Then(@"I send a success email with the file information")]
        public void ThenISendASuccessEmailWithTheFileInformation()
        {
            EmailUtility.sendEmail("Test Workbench", "Member Upload Successed");
            if (fileProcessed)
            {
                // Implement logic to send success email
                Console.WriteLine($"Data is uploaded with {processedFileName} for Members as <MemberID>");
            }
            else
            {
                // Implement logic to send failure email with error logs
                Console.WriteLine($"Data uploaded Not done with {processedFileName} for Members as <MemberID> and <errorLogs>");
            }
        }

        [Given(@"Connect to Database to run query as ""([^""]*)""")]
        public void GivenConnectToDatabaseToRunQueryAs(string p0)
        {
            dbResult = dbConnect.getBatchStatus("");
        }

        [When(@"Print Database query result")]
        public void WhenPrintDatabaseQueryResult()
        {
            //Code to print result
            Console.WriteLine(dbResult);
        }

    }
}
