using AventStack.ExtentReports.Utils;
using Incedo_Automation.src.library.API_libs;
using Incedo_Automation.src.utility;
using Microsoft.AspNetCore.Authentication;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Schema;
using NUnit.Framework;
using RestSharp;
using System;
using System.Text;
using TechTalk.SpecFlow;
using static MongoDB.Bson.Serialization.Serializers.SerializerHelper;

namespace Incedo_Automation.StepDefinitions
{
    [Binding]
    public class API_MemebersStepDefinitions
    {
        StringBuilder tokenValue = new StringBuilder();
        string token_value;
        string strApiResponseValue = null;

        private JObject actualMemberDetails;
        RestResponse apiResponseValue;

        List<Assignment> assignments = new List<Assignment>();

        [Given(@"Valid user credentials to generate Token for Authentication")]
        public void GivenValidUserCredentialsToGenerateTokenForAuthentication()
        {
            token_value = TokenAuth.getToken();
        }
        [Given(@"Valid user credentials to get Invalid Token")]
        public void GivenValidUserCredentialsToGetInvalidToken()
        {
            token_value = "invalid_token";
        }

        [When(@"Launch ""([^""]*)"" endpoint with valid credentials and MemberId as ""([^""]*)""")]
        public void WhenLaunchEndpointWithValidCredentialsAndMemberIdAs(string endpoint, string MemberID)
        {
            Console.WriteLine("Endpoint : " + endpoint + "| MemberID :" + MemberID);
            apiResponseValue = apiRequest.GetAPIRequestAsyncUsingToken("/Member/GetMembersById?memberId=" + MemberID, token_value);
        }

        [When(@"Launch ""([^""]*)"" endpoint with valid credentials and UserName as ""([^""]*)""")]
        public void WhenLaunchEndpointWithValidCredentialsAndUserNameAs(string endpoint, string userName)
        {
            apiResponseValue = apiRequest.GetAPIRequestAsyncUsingToken(endpoint + "?userName=" + userName, token_value);
        }

        [Given(@"Launch api ""([^""]*)"" endpoint with valid credentials")]
        public void GivenLaunchApiEndpointWithValidCredentials(string endpoint)
        {
            apiResponseValue = apiRequest.GetAPIRequestAsyncUsingToken(endpoint, token_value);
        }

        [When(@"Launch ""([^""]*)"" endpoint with valid credentials and memberFirstName as ""([^""]*)"" and memberLastName as ""([^""]*)"" and memberBirthDate as ""([^""]*)""")]
        public void WhenLaunchEndpointWithValidCredentialsAndMemberFirstNameAsAndMemberLastNameAsAndMemberBirthDateAs(string endpoint, string fName, string lName, string dobValue)
        {
            apiResponseValue = apiRequest.GetAPIRequestAsyncUsingToken(endpoint + "?memberFirstName=" + fName + "&memberFirstName=" + fName + "&memberLastName=" + lName + "&memberBirthDate=" + dobValue, token_value);
        }

        [Then(@"Verify endpoint ""([^""]*)"" status code as ""([^""]*)""")]
        public void ThenVerifyEndpointStatusCodeAs(string endPointURL, string statusCode)
        {
            switch (statusCode)
            {
                case "OK":
                    {
                        Assert.AreEqual(System.Net.HttpStatusCode.OK, apiRequest.apiResponse.StatusCode, "Status code not match as per expectation");

                    }
                    break;
                case "Unauthorized":
                    {
                        Assert.AreEqual(System.Net.HttpStatusCode.Unauthorized, apiRequest.apiResponse.StatusCode, "Status code not match as per expectation");

                    }
                    break;
                default:
                    {
                        Assert.AreEqual(System.Net.HttpStatusCode.OK, apiRequest.apiResponse.StatusCode, "Status code not match as per expectation");
                    }
                    break;
            }

        }

        [Then(@"the member details should match the expected structure")]
        public void ThenTheMemberDetailsShouldMatchTheExpectedStructure()
        {

        }

        [Then(@"Check if the ""([^""]*)"" attribute is present")]
        public void ThenCheckIfTheAttributeIsPresent(string attributeName)
        {
            JArray jsonResponse = JArray.Parse(apiResponseValue.Content);
            Assert.IsTrue(jsonResponse[0][attributeName] != null, "The attribute {" + attributeName + "} is not present in the JSON response.");
        }

        [Then(@"Check if the ""([^""]*)"" attribute is present with value as ""([^""]*)""")]
        public void ThenCheckIfTheAttributeIsPresent(string attributeName, string attributeValue)
        {
            JArray jsonResponse = JArray.Parse(apiResponseValue.Content);
            string actualValue = jsonResponse[0][attributeName]?.ToString();
            if (!attributeValue.IsNullOrEmpty())
            {
                Assert.IsTrue((actualValue == attributeValue), "The attribute {" + attributeName + "} value is not match as per input as " + attributeValue + "\n found as " + actualValue);
            }
        }

        [Then(@"Check in Assignment GetUserAssignemnts Endpoint if the ""([^""]*)"" attribute is present")]
        public void ThenCheckInAssignmentGetUserAssignemntsEndpointIfTheAttributeIsPresent(string attributeName)
        {
            assignments = JsonConvert.DeserializeObject<List<Assignment>>(apiResponseValue.Content);
            ScenarioContext.Current.Set(assignments, "Assignments");
            ScenarioContext.Current.Set(attributeName, "AttributeName");
        }

        [Then(@"Check in Assignment GetUserAssignemnts Endpoint if the ""([^""]*)"" attribute is present with value as ""([^""]*)""")]
        public void ThenCheckInAssignmentGetUserAssignemntsEndpointIfTheAttributeIsPresentWithValueAs(string attributeName, string attributeValue)
        {
            List<Assignment> assignmentsList = ScenarioContext.Current.Get<List<Assignment>>("Assignments");
            var actualValue = Assignment.getAttributeValue(assignmentsList, attributeName);

            Assert.AreEqual(attributeValue, actualValue, $"Expected {attributeName} to be {attributeValue}, but found {actualValue}");
        }


    }
}
