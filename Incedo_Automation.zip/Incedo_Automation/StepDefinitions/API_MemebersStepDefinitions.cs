using Incedo_Automation.src.library.API_libs;
using Microsoft.AspNetCore.Authentication;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Schema;
using NUnit.Framework;
using RestSharp;
using System;
using System.Text;
using TechTalk.SpecFlow;
using static MongoDB.Bson.Serialization.Serializers.SerializerHelper;

namespace Incedo_Automation.StepDefinitions
{
    [Binding]
    public class API_MemebersStepDefinitions
    {
        StringBuilder tokenValue = new StringBuilder();
        string token_value;
        string apiResponseValue = null;

        private JObject actualMemberDetails;
        RestResponse apiResponseValue1;

        [Given(@"Valid user credentials to generate Token for Authentication")]
        public void GivenValidUserCredentialsToGenerateTokenForAuthentication()
        {
            token_value = "eyJhbGciOiJSUzI1NiIsImtpZCI6IjU4MzNCNkE3MzQ2MUU4RTMyRjgxQTcyM0NFMTlBNkZFMDE3NkQ3RjBSUzI1NiIsInR5cCI6ImF0K2p3dCIsIng1dCI6IldETzJwelJoNk9NdmdhY2p6aG1tX2dGMjFfQSJ9.eyJuYmYiOjE3MDE5NzE1NTUsImV4cCI6MTcwMTk3NTE1NSwiaXNzIjoiaHR0cHM6Ly9wcmRxYS5hZC5pbmZvbWMuY29tLzc0MS9zZWN1cmVhdXRoZW50aWNhdGlvbiIsImNsaWVudF9pZCI6IjlmNmU5YmQ4LWYwOWYtNGVhNC1iZWVhLTkxODQwZmVkNGU2MCIsImlhdCI6MTcwMTk3MTU1NSwic2NvcGUiOlsiY3JlYXRlbWVtIiwibG9va3JlZiIsIm1lbXNlYXJjaCIsInByb3ZzZWFyY2giXX0.a2HR_k7qK0cdcgsko8ZswITvGLSpznCP4QFS1NcLmg_Ry3S84CdF-S99hazaDY3iX4RhWc7EDQzROPggitrwercgronQywns60zbNRDhBHMAiFF39fdyvzxP0JpHtM5sP5Cffk8lvVMvj6WAxVMC3ZTt0OVtxQR0ASPR7QbGlH3ZpUiG8F8VbsGRtojnli1nv8Kk7VUTdXRaCsa3N0ZO68zPSpVUBN84MQ1cUOSPJNbcKLwxj_dOh04UF9wWzgSshHgvcwLQ9DH_v1aBQN28KnfZzkNmm_cjJBIQ5QyND8Fe99NCadcnsSeqX-_R9ZkJ3jFHQ5B1-pH-J0Z1ddiRGw";//TokenAuth.getToken();
        }

        [When(@"Launch ""([^""]*)"" endpoint with valid credentials and MemberId as ""([^""]*)""")]
        public void WhenLaunchEndpointWithValidCredentialsAndMemberIdAs(string endpoint, string MemberID)
        {
            Console.WriteLine("Endpoint : " + endpoint + "| MemberID :" + MemberID);
            //https://prdqa.ad.infomc.com/741/IncedoApi/api/Member/GetMembersById?memberId=3767
            apiResponseValue1 = apiRequest.GetAPIRequestAsyncUsingToken1("/Member/GetMembersById?memberId=" + MemberID, token_value);
            //actualMemberDetails = JObject.Parse(apiResponseValue1);
        }

        [Given(@"Launch api ""([^""]*)"" endpoint with valid credentials")]
        public void GivenLaunchApiEndpointWithValidCredentials(string endpoint)
        {
            apiResponseValue1 = apiRequest.GetAPIRequestAsyncUsingToken1(endpoint, token_value);
        }

        [When(@"Launch ""([^""]*)"" endpoint with valid credentials and memberFirstName as ""([^""]*)"" and memberLastName as ""([^""]*)"" and memberBirthDate as ""([^""]*)""")]
        public void WhenLaunchEndpointWithValidCredentialsAndMemberFirstNameAsAndMemberLastNameAsAndMemberBirthDateAs(string endpoint, string fName, string lName, string dobValue)
        {
            apiResponseValue1 = apiRequest.GetAPIRequestAsyncUsingToken1(endpoint + "?memberFirstName=" + fName + "&memberFirstName=" + fName + "&memberLastName=" + lName + "&memberBirthDate=" + dobValue, token_value);
            //actualMemberDetails = JObject.Parse(apiResponseValue);
        }

        [Then(@"Verify endpoint ""([^""]*)"" status code as ""([^""]*)""")]
        public void ThenVerifyEndpointStatusCodeAs(string endPointURL, string statusCode)
        {
            Assert.AreEqual(System.Net.HttpStatusCode.OK, apiResponseValue1.StatusCode, "Status code not match as per expectation");
        }

        [Then(@"the member details should match the expected structure")]
        public void ThenTheMemberDetailsShouldMatchTheExpectedStructure()
        {
            // Define the expected schema here
            string expectedSchema = @"
                {
                    'type': 'array',
                    'items': {
                        'type': 'object',
                        'properties': {
                            'memberLastName': {'type': 'string'},
                            'memberFirstName': {'type': 'string'},
                            'memberMiddleInitial': {'type': 'string'},
                            'memberGender': {'type': 'string'},
                            'memberBirthdate': {'type': 'string'},
                            'memberRace': {'type': 'string'},
                            'memberLanguagepref': {'type': 'string'},
                            'memberID': {'type': 'string'},
                            'memberPolicyNo': {'type': 'string'},
                            'memberExternalID': {'type': 'string'},
                            'memberInsurer': {'type': 'string'},
                            'memberInsurerID': {'type': 'string'},
                            'memberAddress': {'type': 'string'},
                            'memberCity': {'type': 'string'},
                            'memberState': {'type': 'string'},
                            'memberZipcode': {'type': 'string'},
                            'memberCountry': {'type': 'string'},
                            'memberCounty': {'type': 'string'},
                            'memberCountycode': {'type': 'string'},
                            'phoneNumber': {'type': 'string'},
                            'memberEmail': {'type': 'string'},
                            'activeAuthorization': {'type': 'boolean'}
                        },
                        'required': [
                            'memberLastName',
                            'memberFirstName',
                            'memberGender',
                            'memberBirthdate',
                            'memberID',
                            'memberAddress',
                            'memberCity',
                            'memberState',
                            'memberZipcode',
                            'memberCountry',
                            'phoneNumber',
                            'activeAuthorization'
                        ]
                    }
                }";

            JSchema expectedJSchema = JSchema.Parse(expectedSchema);

            // Perform the actual validation
            bool isValid = actualMemberDetails.IsValid(expectedJSchema);

            Assert.IsTrue(isValid, "Member details do not match the expected structure");
        }


    }
}
