﻿using AventStack.ExtentReports;
using BoDi;
using Incedo_Automation.src.utility;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using System.Diagnostics;
using TechTalk.SpecFlow;

namespace Incedo_Automation.src.hooks
{
    [Binding]
    public sealed class Hooks
    {
        private readonly IObjectContainer _container;

        public Hooks(IObjectContainer container)
        {
            _container = container;
        }

        [BeforeScenario("@TestApi")]
        public void BeforeScenarioWithTag()
        {
            Console.WriteLine("Execution for @TestApi tag is started...");
        }

        //[BeforeScenario(Order = 1)]
        //public void FirstBeforeScenario()
        //{
        //    IWebDriver driver = new ChromeDriver();
        //    driver.Manage().Window.Maximize();
        //    _container.RegisterInstanceAs<IWebDriver>(driver);
        //}

        //[AfterScenario]
        //public void AfterScenario()
        //{
        //    var driver = _container.Resolve<IWebDriver>();

        //    if (driver != null)
        //    {
        //        driver.Quit();
        //    }

        //}

        [AfterTestRun]
        public static void AfterTestRun()
        {
            ExecuteCommand("livingdoc test-assembly Incedo_Automation.dll -t TestExecution.json");

        }

        public static void ExecuteCommand(string Command)
        {
            ProcessStartInfo ProcessInfo;
            Process Process;

            ProcessInfo = new ProcessStartInfo("cmd.exe", "/K " + Command);
            ProcessInfo.CreateNoWindow = true;
            ProcessInfo.UseShellExecute = true;

            Process = Process.Start(ProcessInfo);

            Process.CloseMainWindow();
        }

    }
}