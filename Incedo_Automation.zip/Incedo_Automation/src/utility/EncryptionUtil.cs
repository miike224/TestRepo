﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Incedo_Automation.src.utils
{
    internal class EncryptionUtil
    {
        private EncryptionUtil() { }

        public static string EncodeKey(string key)
        {
            byte[] encodedKeyBytes = Encoding.UTF8.GetBytes(key);
            string encodedKey = Convert.ToBase64String(encodedKeyBytes);
            return encodedKey;
        }

        public static string DecodeKey(string keyToDecode)
        {
            byte[] decodedKeyBytes = Convert.FromBase64String(keyToDecode);
            string decodedKey = Encoding.UTF8.GetString(decodedKeyBytes);
            return decodedKey;
        }

        //public static void Main(string[] args)
        //{
        //    string key = EncodeKey("Te$tf@ct0ry*1");
        //    Console.WriteLine(key);
        //}
    }
}
