﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace Incedo_Automation.src.utility
{


    public class AppConfig
    {
        public static string getProperty(string key)
        {
            string binPath = AppDomain.CurrentDomain.BaseDirectory;
            string mainProjectPath = Path.GetFullPath(Path.Combine(binPath, "..", "..", ".."));

            string jsonFilePath = System.IO.Path.Combine(mainProjectPath, "src", "Config", "appSettings.json");

            // Set up configuration
            IConfiguration _configuration = new ConfigurationBuilder()
                .AddJsonFile(jsonFilePath) // Specify the path to your appsettings.json file
                .Build();

            return _configuration["MyConfig:" + key];
        }

        public static string getEmailProperty(string key)
        {
            string binPath = AppDomain.CurrentDomain.BaseDirectory;
            string mainProjectPath = Path.GetFullPath(Path.Combine(binPath, "..", "..", ".."));

            string jsonFilePath = System.IO.Path.Combine(mainProjectPath, "src", "Config", "appSettings.json");

            // Set up configuration
            IConfiguration _configuration = new ConfigurationBuilder()
                .AddJsonFile(jsonFilePath) // Specify the path to your appsettings.json file
                .Build();

            return _configuration["MyEmail:" + key];
        }

        public static string getDatabaseProperty(string key)
        {
            string binPath = AppDomain.CurrentDomain.BaseDirectory;
            string mainProjectPath = Path.GetFullPath(Path.Combine(binPath, "..", "..", ".."));

            string jsonFilePath = System.IO.Path.Combine(mainProjectPath, "src", "Config", "appSettings.json");

            // Set up configuration
            IConfiguration _configuration = new ConfigurationBuilder()
                .AddJsonFile(jsonFilePath) // Specify the path to your appsettings.json file
                .Build();

            return _configuration["myDatabaseConnection:" + key];
        }

    }

}
