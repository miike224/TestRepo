﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Net.Mime;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using RestSharp;

namespace Incedo_Automation.src.utility
{
    internal class EmailUtility
    {
        public static async Task SendEmailAsync(string fromEmail, string toEmail, string subject, string body, string attachmentPath = null)
        {
            try
            {
                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(fromEmail);
                mailMessage.To.Add(toEmail);
                mailMessage.Subject = subject;
                mailMessage.Body = body;

                if (!string.IsNullOrEmpty(attachmentPath))
                {
                    Attachment attachment = new Attachment(attachmentPath, MediaTypeNames.Application.Octet);
                    ContentDisposition disposition = attachment.ContentDisposition;
                    disposition.CreationDate = File.GetCreationTime(attachmentPath);
                    disposition.ModificationDate = File.GetLastWriteTime(attachmentPath);
                    disposition.ReadDate = File.GetLastAccessTime(attachmentPath);

                    mailMessage.Attachments.Add(attachment);
                }

                using (SmtpClient smtpClient = new SmtpClient("smtp.office365.com"))
                {
                    smtpClient.Port = 587;
                    smtpClient.Credentials = new NetworkCredential("micheal.dirikebamor@infomc.com", "infomc2023!");
                    smtpClient.EnableSsl = true;

                    await smtpClient.SendMailAsync(mailMessage);
                }

                Console.WriteLine("Email sent successfully!");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error sending email: {ex.Message}");
            }
        }

        public static void SendEmail(string fromEmail, string toEmail, string subject, string body, string attachmentPath = null)
        {
            try
            {
                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(fromEmail);
                mailMessage.To.Add(toEmail);
                mailMessage.Subject = subject;
                mailMessage.Body = body;

                if (!string.IsNullOrEmpty(attachmentPath))
                {
                    Attachment attachment = new Attachment(attachmentPath, MediaTypeNames.Application.Octet);
                    ContentDisposition disposition = attachment.ContentDisposition;
                    disposition.CreationDate = File.GetCreationTime(attachmentPath);
                    disposition.ModificationDate = File.GetLastWriteTime(attachmentPath);
                    disposition.ReadDate = File.GetLastAccessTime(attachmentPath);

                    mailMessage.Attachments.Add(attachment);
                }

                using (SmtpClient smtpClient = new SmtpClient("smtp.office365.com"))
                {
                    smtpClient.Port = 587;
                    smtpClient.Credentials = new NetworkCredential("micheal.dirikebamor@infomc.com", "infomc2023!");
                    smtpClient.EnableSsl = true;

                    smtpClient.SendMailAsync(mailMessage);
                }

                Console.WriteLine("Email sent successfully!");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error sending email: {ex.Message}");
            }
        }
        public static void CallEmailSendSample()
        {
            string fromEmail = "your_email@example.com";
            string toEmail = "recipient_email@example.com";
            string subject = "Test Email";
            string body = "This is a test email.";
            string attachmentPath = "C:\\path\\to\\your\\attachment.txt"; // Replace with the actual attachment path

            SendEmailAsync(fromEmail, toEmail, subject, body, attachmentPath).Wait();
        }

        public static void sendEmail(string subject, string body, string attachmentPath = null)
        {
            string fromEmail = AppConfig.getEmailProperty("fromEmail");
            string toEmail = AppConfig.getEmailProperty("toEmail");

            SendEmail(fromEmail, toEmail, subject, body, attachmentPath);
        }
    }
}
