﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Incedo_Automation.src.utility
{
    internal class Assignment
    {
        public int AssignmentID { get; set; }
        public string Subject { get; set; }
        public string AssignmentDueDate { get; set; }
        public string TimeRemaining { get; set; }
        public string AssignmentType { get; set; }
        public string AssignmentTypeID { get; set; }
        public string RegardingEntityName { get; set; }
        public string AssignmentStatus { get; set; }
        public string AssignmentPriority { get; set; }
        public string AssignmentOwnerName { get; set; }
        public string AssignmentOwningGroup { get; set; }
        public string LinkedEpisodeNumber { get; set; }

        public static string getAttributeValue(List<Assignment> DataList, string attributeName, int index = 0)
        {
            string value = null;
            switch (attributeName)
            {
                case "Subject":
                    {
                        value = DataList[index].Subject;

                    }
                    break;
                default:
                    {
                        value = DataList[index].AssignmentID.ToString();
                    }
                    break;
            }

            return value;
        }

    }
}
