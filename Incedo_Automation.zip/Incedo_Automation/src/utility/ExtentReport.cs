﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;


namespace Incedo_Automation.src.utility
{
    internal class ExtentReport
    {
        private static ExtentReports _extent;
        private static ExtentTest _test;

        public static void SetupExtentReport()
        {
            //var htmlReporter = new ExtentHtmlReporter("path/to/extent-report.html");
            _extent = new ExtentReports();
            //_extent.AttachReporter(htmlReporter);
        }

        public static void CreateTest(string testName)
        {
            _test = _extent.CreateTest(testName);
        }

        public static void LogTestStatus(Status status, string message)
        {
            _test.Log(status, message);
        }

        public static void FlushExtentReport()
        {
            _extent.Flush();
        }
    }
}
