﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Incedo_Automation.src.utility
{
    internal class dbConnect
    {
        public static string connectionString = "";//= "Data Source=IMSQL19QA02;Initial Catalog=OMD_QA_731_G70ProcessLog;Integrated Security=True;";

        static dbConnect()
        {
            connectionString = "Data Source=" + AppConfig.getDatabaseProperty("dataSource") + ";Initial Catalog=" + AppConfig.getDatabaseProperty("databaseName") + ";Integrated Security=True;";
        }
        public static string getBatchStatus(string sqlQuery, int colCount = 1)
        {
            // Replace with your connection string
            // string connectionString = "Data Source=YourServerName;Initial Catalog=YourDatabaseName;Integrated Security=True;";

            string results = "";
            // Create a SqlConnection object
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    // Open the connection
                    connection.Open();

                    // Connection is open, perform database operations here

                    // Example: Execute a SQL query
                    using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                for (int i = 0; i < colCount; i++)
                                {
                                    // Process the data
                                    results = results + reader[i] + "|";
                                }
                                results = results + "\n";
                                Console.WriteLine(results);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Handle exceptions
                    Console.WriteLine($"Error: {ex.Message}");
                    Assert.Fail(ex.Message);
                }
                return results;
            }
        }

    }
}
