﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using NUnit.Framework;
using Incedo_Automation.src.utility;
using TechTalk.SpecFlow;
using AventStack.ExtentReports.Model;
using Newtonsoft.Json.Linq;
using System.Net.Http.Headers;

namespace Incedo_Automation.src.library.API_libs
{
    internal class TokenAuth
    {
        public static string authUrl = "", clientId = "", clientSecret = "";
        public static string authToken;
        public static string getToken()
        {
            authUrl = AppConfig.getProperty("authUrl");
            clientId = AppConfig.getProperty("clientId");
            clientSecret = AppConfig.getProperty("clientSecret");

            var client = new RestClient(authUrl);
            var request = new RestRequest("/Token", Method.Post); // Make sure to append "/Token" to the base URL
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/x-www-form-urlencoded");

            // Use AddParameter to add form parameters
            request.AddParameter("grant_type", "client_credentials");
            request.AddParameter("client_id", clientId);
            request.AddParameter("client_secret", clientSecret);

            // Execute the request
            RestResponse response = client.Execute(request);

            // Check if the request was successful (status code 200)
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                Console.WriteLine("Token successfully generated:");
                Console.WriteLine(response.Content);

                // Use Json.NET to parse the response content
                dynamic resp = JObject.Parse(response.Content);
                string token = resp.access_token;

                Console.WriteLine($"Access Token: {token}");
                authToken = token;
                return token;
            }
            else
            {
                Console.WriteLine($"Error generating token. Status Code: {response.StatusCode}");
                Console.WriteLine(response.Content);
            }

            return "";
        }
    }
    // Define a class to represent the structure of the JSON response
    public class TokenResponse
    {
        public string access_token { get; set; }
        public int expires_in { get; set; }
        public string token_type { get; set; }
        public string scope { get; set; }
    }
}
