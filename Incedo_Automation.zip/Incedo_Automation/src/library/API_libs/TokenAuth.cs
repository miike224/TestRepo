﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using NUnit.Framework;
using Incedo_Automation.src.utility;
using TechTalk.SpecFlow;
using AventStack.ExtentReports.Model;
using Newtonsoft.Json.Linq;
using System.Net.Http.Headers;

namespace Incedo_Automation.src.library.API_libs
{
    internal class TokenAuth
    {
        public static string authUrl = "", clientId = "", clientSecret = "";


        public static string getToken()
        {
            return "eyJhbGciOiJSUzI1NiIsImtpZCI6IjU4MzNCNkE3MzQ2MUU4RTMyRjgxQTcyM0NFMTlBNkZFMDE3NkQ3RjBSUzI1NiIsInR5cCI6ImF0K2p3dCIsIng1dCI6IldETzJwelJoNk9NdmdhY2p6aG1tX2dGMjFfQSJ9.eyJuYmYiOjE3MDE3OTY3NTQsImV4cCI6MTcwMTgwMDM1NCwiaXNzIjoiaHR0cHM6Ly9wcmRxYS5hZC5pbmZvbWMuY29tLzc0MS9zZWN1cmVhdXRoZW50aWNhdGlvbiIsImNsaWVudF9pZCI6IjlmNmU5YmQ4LWYwOWYtNGVhNC1iZWVhLTkxODQwZmVkNGU2MCIsImlhdCI6MTcwMTc5Njc1NCwic2NvcGUiOlsiY3JlYXRlbWVtIiwibG9va3JlZiIsIm1lbXNlYXJjaCIsInByb3ZzZWFyY2giXX0.Pth1jgvYkGGvAWqXdIfjk5VO91jfryOa11aHrCpaIANbiuvvSM_t4EVak8bNIdhV-55xNxKpXtevxGJUZp3ieXVY18Twh00lsMpY-hof95P0JzC-VHrFDmODUoClw1C3lMv9dp3wH7vDZkd_Gfnp_6pkEHm8VUEuR-AjkmctwOJl2IqLw8vVKPhVyDLmqbZ-c7dPxHxz5wEzF2snY_faUnBz2cn-ZXBQ5mCaiyEwHpRtzqZaRI_jvrA86mqwDDOnPFIjwtAGs3dcvw04B0ygX0MXRfghJANHw5ja3iK3jRBGXqyaHwDx3cI-cuH7XD29r-5pDcVddahc0LfLG4VGLg";

            authUrl = AppConfig.getProperty("authUrl");
            clientId = AppConfig.getProperty("clientId");
            clientSecret = AppConfig.getProperty("clientSecret");

            var client = new RestClient(authUrl);
            var request = new RestRequest(authUrl, Method.Post);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/x-www-form-urlencoded");
            request.AddParameter("application/x-www-form-urlencoded", "grant_type=client_credentials&client_id=" + clientId + "&client_secret=" + clientSecret, ParameterType.RequestBody);
            RestResponse response = client.Execute(request);

            Console.WriteLine(response.Content);

            dynamic resp = JObject.Parse(response.Content);
            string token = resp.access_token;

            //return token;


            // Check if the request was successful (status code 200)
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                Console.WriteLine("Token successfully generated:");
                Console.WriteLine(response.Content);
                string jsonInput = response.Content;
                //dynamic resp = JObject.Parse(response.Content);
                //string token = resp.access_token;

                return token;
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.BadRequest)
            {
                Assert.Fail(response.Content);
            }
            else
            {
                Console.WriteLine($"Error generating token. Status Code: {response.StatusCode}");
                Console.WriteLine(response.Content);
            }

            return null;
        }

        public static StringBuilder getTokenTest1()
        {

            string authUrl = "https://aetsup.ad.infomc.com/741/SecureAuthentication/Connect";
            //https://prdqa.ad.infomc.com/741/SecureAuthentication/Connect/Token
            //    9f6e9bd8 - f09f - 4ea4 - beea - 91840fed4e60
            //        JaP4 + 8ol5CPZsCpSqrMR5hx8MhqbBDoeFQNJcQWpkLg =
            string clientId = "9f6e9bd8-f09f-4ea4-beea-91840fed4e60";
            string clientSecret = "JaP4+8ol5CPZsCpSqrMR5hx8MhqbBDoeFQNJcQWpkLg=";
            // Create a RestClient
            var client = new RestClient(authUrl);

            // Create a RestRequest with the endpoint and method
            var request = new RestRequest("/Token", Method.Post);

            // Add required parameters for token generation
            request.AddParameter("grant_type", "client_credentials");
            request.AddParameter("client_id", clientId);
            request.AddParameter("client_secret", clientSecret);

            // Add Content-Type header
            request.AddHeader("Content-Type", "application/x-www-form-urlencoded");

            // Execute the request
            var response = client.Execute(request);

            // Log the entire response for debugging purposes
            Console.WriteLine($"Response Content: {response.Content}");
            Console.WriteLine($"Response Headers: {response.Headers}");

            // Check if the request was successful (status code 200)
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                Console.WriteLine("Token successfully generated:");
                Console.WriteLine(response.Content);
                string jsonInput = response.Content;
                // Deserialize the JSON
                TokenResponse tokenResponse = JsonConvert.DeserializeObject<TokenResponse>(jsonInput);

                // Access the access_token property
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.Append(tokenResponse.access_token);
                return stringBuilder;
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.BadRequest)
            {
                Assert.Fail(response.Content);
            }
            else
            {
                Console.WriteLine($"Error generating token. Status Code: {response.StatusCode}");
                Console.WriteLine(response.Content);
            }


            return null;
        }
    }
    // Define a class to represent the structure of the JSON response
    public class TokenResponse
    {
        public string access_token { get; set; }
        public int expires_in { get; set; }
        public string token_type { get; set; }
        public string scope { get; set; }
    }
}
