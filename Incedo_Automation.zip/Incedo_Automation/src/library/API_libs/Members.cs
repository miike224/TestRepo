﻿using AventStack.ExtentReports;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Incedo_Automation.src.library.API_libs
{
    internal class Members
    {
        //        var options = new RestClientOptions("")
        //        {
        //            MaxTimeout = -1,
        //        };
        //        var client = new RestClient(options);
        //        var request = new RestRequest("https://prdqa.ad.infomc.com/741/IncedoApi/api/Member/GetMembersById?memberId=3767", Method.Get);
        //        request.AddHeader("Accept", "application/json");
        //request.AddHeader("Authorization", "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6IjU4MzNCNkE3MzQ2MUU4RTMyRjgxQTcyM0NFMTlBNkZFMDE3NkQ3RjBSUzI1NiIsInR5cCI6ImF0K2p3dCIsIng1dCI6IldETzJwelJoNk9NdmdhY2p6aG1tX2dGMjFfQSJ9.eyJuYmYiOjE3MDA1ODQ4MzUsImV4cCI6MTcwMDU4ODQzNSwiaXNzIjoiaHR0cHM6Ly9wcmRxYS5hZC5pbmZvbWMuY29tLzc0MS9zZWN1cmVhdXRoZW50aWNhdGlvbiIsImNsaWVudF9pZCI6IjlmNmU5YmQ4LWYwOWYtNGVhNC1iZWVhLTkxODQwZmVkNGU2MCIsImlhdCI6MTcwMDU4NDgzNSwic2NvcGUiOlsiY3JlYXRlbWVtIiwibG9va3JlZiIsIm1lbXNlYXJjaCIsInByb3ZzZWFyY2giXX0.mSsaliSMy_SQmbMm8nf2rYy8ALW2aT9tYGvr5wURZrYZGFKZouk0mEejRBb01TX44EpQZHQIx-WoFloPQXr5Yjc___LALZ_Nl7glxmaIceGsIHmuBkWrj6C4kwALI1L9BTfAJGKTb6_rsSnrWh-0_r_AdCn9FMocQGZBWPqIAHvpEcEJd3W4EXRhNgdyJXCTdpEv7ORL-LkNYLULM3Hri1gZpsJIpqE4_S5bweEf571Dx9nfgst9Anzb6ag7PQAHjSkbd9IPzNeAfTqWjxjYdpapGAHYqbHPFyzK0pdy2e7foZccL8ZIanrxRPXdOC1mUzeHJkQQ8ZRS_DyewnSryw");
        //RestResponse response = await client.ExecuteAsync(request);
        //        Console.WriteLine(response.Content);

        public void getMembersDetailsByMemberID(string token_id, string memberID)
        {
            string apiEndpoint = "/Member/GetMembersById?memberId=" + memberID;
            apiRequest.GetAPIRequestAsync(apiEndpoint);

        }

        public string getMemberUploadStatus(int status)
        {
            switch (status)
            {
                case 0:
                    Console.WriteLine("NOT STARTED");
                    break;

                case 1:
                    Console.WriteLine("RUNNING");
                    break;

                case 2:
                    Console.WriteLine("PAUSED");
                    break;

                case 3:
                    Console.WriteLine("COMPLETED");
                    break;

                case 4:
                    Console.WriteLine("FAILED");
                    break;

                case 5:
                    Console.WriteLine("REJECTED");
                    break;

                case 6:
                    Console.WriteLine("RESUBMITTED");
                    break;

                case 7:
                    Console.WriteLine("COMPLETED WITH WARNINGS");
                    break;

                default:
                    Console.WriteLine("Unknown status");
                    break;
            }
            return "";
        }
    }
}
