﻿using Gherkin;
using Incedo_Automation.src.utility;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Incedo_Automation.src.library.API_libs
{
    internal class apiRequest
    {
        public static string BaseUrl = "https://prdqa.ad.infomc.com/741/IncedoApi/api/";
        public static RestResponse apiResponse;

        public static RestResponse APIRequestAsync(string apiEndpoint, Method MethodType)
        {
            var options = new RestClientOptions(BaseUrl)
            {
                MaxTimeout = -1,
            };
            var client = new RestClient(options);
            var request = new RestRequest(apiEndpoint, MethodType);
            RestResponse response = client.Execute(request);
            Console.WriteLine(response.Content);

            return response;
        }

        public static RestResponse GetAPIRequestAsync(string apiEndpoint)
        {
            return APIRequestAsync(apiEndpoint, Method.Get);
        }

        public static RestResponse GetAPIRequestAsyncUsingToken1(string apiEndpoint, string token_id)
        {
            var options = new RestClientOptions(BaseUrl)
            {
                MaxTimeout = -1,
            };
            var client = new RestClient(options);
            //var request = new RestRequest(AppConfig.getProperty("BaseURL") + "Member/GetMembersById?memberId=3767", Method.Get);
            var request = new RestRequest(AppConfig.getProperty("BaseURL") + apiEndpoint, Method.Get);
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Authorization", "Bearer " + token_id);

            RestResponse response = client.Execute(request);
            Console.WriteLine(response.Content);

            // Check if the request was successful (status code 200)
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                Console.WriteLine("Request successful:");
                Console.WriteLine(response);
                return response;
            }
            else
            {
                Console.WriteLine($"Error in the request. Status Code: {response.StatusCode}");
                Console.WriteLine(response);
            }
            return null;
        }

        public static string GetAPIRequestAsyncUsingToken(string apiEndpoint, string token_id)
        {
            var baseUrl = AppConfig.getProperty("BaseURL");
            var apiUrl = apiEndpoint;// "Member/GetMembersById?memberId=3767";
            var token = "Bearer " + token_id;

            // Log the complete URL for debugging
            Console.WriteLine($"Complete URL: {baseUrl}{apiUrl}");

            var client = new RestClient(baseUrl + apiUrl);
            var request = new RestRequest(baseUrl + apiUrl, Method.Get);
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Authorization", token);
            RestResponse response = client.Execute(request);
            Console.WriteLine(response.Content);

            apiResponse = response;

            return response.Content.ToString();
        }

        public static RestResponse DeleteAPIRequestAsync(string apiEndpoint)
        {
            return APIRequestAsync(apiEndpoint, Method.Delete);
        }


        /// <summary>
        /// Method to request api with POST Method
        /// </summary>
        /// <param name="apiEndpoint"> it's Endpoint which we need to hit. i.e. "users/create"</param>
        /// <param name="requestBody">it will be as per format, which can be xml or Json. this should be given as string</param>
        /// <param name="requestHeader">user can add as much as header they want. if there are multiple values it will input as, "Content-Type:text/plain;Accept:*/*;Connection:keep-alive"</param>
        /// <param name="requestParams">user can give parameter as per requirement if its more then it will input as, "id=123&price=234&name=rock"</param>
        /// <returns></returns>
        public static async Task<RestResponse> PostApiRequestAsync(string apiEndpoint, string requestBody, string requestHeader, string requestParams)
        {
            var options = new RestClientOptions(BaseUrl)
            {
                MaxTimeout = -1,
            };

            var client = new RestClient(options);
            var request = new RestRequest(apiEndpoint, Method.Post);

            // Add request header
            if (!string.IsNullOrEmpty(requestHeader))
            {
                var headers = requestHeader.Split(';');
                foreach (var header in headers)
                {
                    var headerParts = header.Split(':');
                    if (headerParts.Length == 2)
                    {
                        request.AddHeader(headerParts[0], headerParts[1]);
                    }
                }
            }

            // Add request parameters
            if (!string.IsNullOrEmpty(requestParams))
            {
                var parameters = requestParams.Split('&');
                foreach (var parameter in parameters)
                {
                    var paramParts = parameter.Split('=');
                    if (paramParts.Length == 2)
                    {
                        request.AddParameter(paramParts[0], paramParts[1]);
                    }
                }
            }

            // Set request body
            request.AddParameter("text/plain", requestBody, ParameterType.RequestBody);

            // Execute the request asynchronously
            var response = await client.ExecuteAsync(request);
            Console.WriteLine(response.Content);

            return response;
        }


        //Duplicate method, can use post method to run put request
        /// <summary>
        /// Method to request api with PUT Method
        /// </summary>
        /// <param name="apiEndpoint"> it's Endpoint which we need to hit. i.e. "update/users/2"</param>
        /// <param name="requestBody">it will be as per format, which can be xml or Json. this should be given as string</param>
        /// <param name="requestHeader">user can add as much as header they want. if there are multiple values it will input as, "Content-Type:text/plain;Accept:*/*;Connection:keep-alive"</param>
        /// <param name="requestParams">user can give parameter as per requirement if its more then it will input as, "id=123&price=234&name=rock"</param>
        /// <returns></returns>
        public static async Task<RestResponse> PutApiRequestAsync(string apiEndpoint, string requestBody, string requestHeader, string requestParams)
        {
            var options = new RestClientOptions(BaseUrl)
            {
                MaxTimeout = -1,
            };

            var client = new RestClient(options);
            var request = new RestRequest(apiEndpoint, Method.Post);

            // Add request header
            if (!string.IsNullOrEmpty(requestHeader))
            {
                var headers = requestHeader.Split(';');
                foreach (var header in headers)
                {
                    var headerParts = header.Split(':');
                    if (headerParts.Length == 2)
                    {
                        request.AddHeader(headerParts[0], headerParts[1]);
                    }
                }
            }

            // Add request parameters
            if (!string.IsNullOrEmpty(requestParams))
            {
                var parameters = requestParams.Split('&');
                foreach (var parameter in parameters)
                {
                    var paramParts = parameter.Split('=');
                    if (paramParts.Length == 2)
                    {
                        request.AddParameter(paramParts[0], paramParts[1]);
                    }
                }
            }

            // Set request body
            request.AddParameter("text/plain", requestBody, ParameterType.RequestBody);

            // Execute the request asynchronously
            var response = await client.ExecuteAsync(request);
            Console.WriteLine(response.Content);

            return response;
        }

    }
}
